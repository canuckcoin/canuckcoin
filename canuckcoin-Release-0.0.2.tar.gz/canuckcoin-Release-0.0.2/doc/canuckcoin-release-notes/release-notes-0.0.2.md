Canuckcoin Core version 0.0.2 is now available

Some minor tweaks to cosmetics, copyright fixing (to make sure Litecoin core is included properly) and finished the rebranding

